package paper;

public interface Elemental {
	public final static byte 
		EL_NONE = 0, 
		EL_FIRE = 1,
		EL_ICE = 2,
		EL_ICYFIRE = 3;
}
