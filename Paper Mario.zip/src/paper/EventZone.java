package paper;

public class EventZone {

}
