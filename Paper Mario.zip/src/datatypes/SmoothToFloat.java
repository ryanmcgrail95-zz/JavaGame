package datatypes;

public class SmoothToFloat extends Automatic {
	private float value, toValue, weight;
	
	public void set(float value) 		{this.value = value;}
	public void setTo(float toValue) 	{this.toValue = toValue;}
	public void setWeight(float weight) {this.weight = weight;}
	
	public float get() 					{return value;}
	public float getTo() 				{return toValue;}
	public float getWeight()			{return weight;}
	
	private float 
}
