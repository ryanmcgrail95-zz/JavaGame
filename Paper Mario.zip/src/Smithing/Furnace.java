package Smithing;

public class Furnace {

}
