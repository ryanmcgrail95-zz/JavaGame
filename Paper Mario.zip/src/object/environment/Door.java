package object.environment;

public class Door {
}
