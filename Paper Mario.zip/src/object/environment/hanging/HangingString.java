package object.environment.hanging;

public class HangingString {
	public void drawSegment(float x1, float y1, float x2, float y2, float h, int numItems) {
		
	}
}
