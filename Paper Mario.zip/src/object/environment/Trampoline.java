package object.environment;

public class Trampoline {

}
