package object.environment;

public class Firebar {
	double direction = 0;
	
	public void update(float deltaT) {
		//direction += img;
	}
}
