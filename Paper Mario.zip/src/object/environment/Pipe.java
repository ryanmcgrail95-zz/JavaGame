package object.environment;

public class Pipe {

}
