package object.environment;

public class Foliage {
}
