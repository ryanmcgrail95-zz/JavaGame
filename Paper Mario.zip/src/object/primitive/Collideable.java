package object.primitive;

public interface Collideable {
	
	public abstract boolean collide(Physical other);
}
