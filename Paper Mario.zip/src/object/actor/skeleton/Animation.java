package object.actor.skeleton;

public class Animation {
	
}
