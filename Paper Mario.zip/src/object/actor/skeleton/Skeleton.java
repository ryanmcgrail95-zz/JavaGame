package object.actor.skeleton;

import datatypes.vec3;

public class Skeleton {
	Animation currentAnimation;
}
