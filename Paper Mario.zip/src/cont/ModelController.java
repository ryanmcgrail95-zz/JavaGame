package cont;

public class ModelController {

}
