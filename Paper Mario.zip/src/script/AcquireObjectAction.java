package script;

public class AcquireObjectAction extends Action {
	
	public AcquireObjectAction(String name, byte[] parameterList) {
		super(name, parameterList);
		// TODO Auto-generated constructor stub
	}

	public static void ini() {
		
	}

	public Variable run(Variable... parameters) {
		if(para)
		
		Object o;
		if(o = findObject())
	}
}
