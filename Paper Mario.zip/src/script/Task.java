package script;

import java.awt.Component;

public class Task {
	private Action action;
	private Variable[] parameters;
	private Variable outputVar;

	public Task(Action action, Variable[] parameters, Variable outputVar) {
		this.action = action;
		this.parameters = parameters;
		this.outputVar = outputVar;
	}
	
	public Action getAction() {
		return action;
	}
	
	public void destroy() {
		if(outputVar != null)
			outputVar.destroy();

		for(Variable v : parameters)
			v.destroy();
		
		action = null;
		parameters = null;
		outputVar = null;
	}
	
	public Variable run() {
		return action.run(outputVar, parameters);
	}

	public Variable getOutputVariable() {
		return outputVar;
	}

	public Variable[] getParameters() {return parameters;}
}
