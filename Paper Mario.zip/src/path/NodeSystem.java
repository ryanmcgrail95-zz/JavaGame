package path;

public class NodeSystem {
	
}
