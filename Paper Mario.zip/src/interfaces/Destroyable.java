package interfaces;

public interface Destroyable {
	public void destroy();
}
