package interfaces;

import object.actor.Actor;

public interface Useable {
	public void use(Actor user);
}
