==--==--==--==--==--== Paper Mario Model ==--==--==--==--==--==

		Battle Stages: Pleasant Path #1

		Ripped by MasterGamePro

===============================================================

The stage is saved as an .obj file, but it is unique because it
preserves the vertex colors from the original game. Each vertex
line has three additional double values to parse; these are the
RGB values of the vertex. Please keep this in mind when you use
the model--if you are getting errors, your .obj loader might
not support vertex colors.

The model does not preserve the original animations. The
following animations are lost in the model:
- the flowers on the bush move up and down

The textures are all located inside the Textures folder. If you
use any of my other models, then extract them into the same
folder. The textures are shared among them to prevent 
redundancy.

This model is free to use, but please provide credit.